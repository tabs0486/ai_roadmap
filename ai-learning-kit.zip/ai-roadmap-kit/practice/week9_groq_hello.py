"""Week 9-10 practice: your first LLM call with Groq.

Setup (one time):
  Mac/Linux:  export GROQ_API_KEY="gsk_..."
  Windows PS: $env:GROQ_API_KEY="gsk_..."
Run: python practice/week9_groq_hello.py
"""
import os

from groq import Groq

client = Groq(api_key=os.environ["GROQ_API_KEY"])
MODEL = "llama-3.3-70b-versatile"


def ask(prompt: str, system: str = "You are a helpful assistant.", temperature: float = 0.3) -> str:
    resp = client.chat.completions.create(
        model=MODEL,
        temperature=temperature,
        messages=[{"role": "system", "content": system},
                  {"role": "user", "content": prompt}],
    )
    return resp.choices[0].message.content


# 1. Basic call
print(ask("Explain what an API is in two sentences."))

# 2. Prompting techniques - compare outputs
print("\n--- Few-shot ---")
print(ask(
    "Classify sentiment.\nText: 'Loved it' -> positive\nText: 'Waste of money' -> negative\n"
    "Text: 'Not bad at all' ->"
))

print("\n--- Structured output (JSON) ---")
print(ask("Extract name and city as JSON only: 'Ravi lives in Pune and likes chess.'",
          system="Reply with valid JSON only, no extra text.", temperature=0))

# TODO 1: compare temperature 0 vs 1.2 for "Write a tagline for a coffee shop" (run 3 times each)
# TODO 2: write a system prompt that makes the model a strict SQL tutor
# TODO 3: build a CLI chat loop that keeps conversation history in a list
