"""Week 3-4 practice: NumPy + Pandas. Run: python practice/week3_pandas_numpy.py"""
import numpy as np
import pandas as pd

# NumPy
a = np.array([1, 2, 3, 4, 5])
print("mean:", a.mean(), "std:", a.std(), "squared:", a ** 2)

# Pandas: build a small dataset
df = pd.DataFrame({
    "city": ["Delhi", "Mumbai", "Chennai", "Delhi", "Mumbai", "Chennai"],
    "sales": [250, 300, 180, 220, 340, 210],
    "month": ["Jan", "Jan", "Jan", "Feb", "Feb", "Feb"],
})
print(df.head())
print(df.describe())
print(df.groupby("city")["sales"].sum())

# TODO 1: find the city with the highest total sales
# TODO 2: add a column "sales_k" = sales / 1000
# TODO 3: filter rows where sales > 250
# TODO 4: save the result with df.to_csv("practice/sales.csv", index=False)
