"""Week 1-2 practice: Python fundamentals. Run: python practice/week1_python_basics.py
Complete every TODO, then check your answers by running the file."""

# 1. Variables, types, f-strings
name = "Your Name"
print(f"Hello {name}, welcome to AI!")

# 2. Lists + loops
scores = [72, 88, 95, 60, 79]
total = 0
for s in scores:
    total += s
print("Average:", total / len(scores))
# TODO: print the highest and lowest score using max() and min()

# 3. Dictionaries
student = {"name": "Asha", "skills": ["python", "sql"]}
student["skills"].append("ml")
print(student)
# TODO: add a key "level" with value "beginner" and print it

# 4. Functions
def word_count(text: str) -> dict:
    counts = {}
    for word in text.lower().split():
        counts[word] = counts.get(word, 0) + 1
    return counts

print(word_count("the cat and the hat"))
# TODO: write is_palindrome(text) and test it on "madam"

# 5. Files + JSON
import json
with open("practice/notes.json", "w") as f:
    json.dump({"week": 1, "done": True}, f)
with open("practice/notes.json") as f:
    print(json.load(f))

# 6. Mini challenge (TODO): build a number-guessing game using input() and random.randint
