"""Week 5-8 practice: your first ML model with scikit-learn.
Run: python practice/week5_ml_iris.py"""
from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split

X, y = load_iris(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

for model in [LogisticRegression(max_iter=500), RandomForestClassifier(random_state=42)]:
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    print(type(model).__name__, "accuracy:", round(accuracy_score(y_test, preds), 3))

print(classification_report(y_test, preds))

# TODO 1: try KNeighborsClassifier and DecisionTreeClassifier; which is best?
# TODO 2: use cross_val_score (cv=5) instead of a single split
# TODO 3: swap in load_breast_cancer() and compare results
# TODO 4: explain in 3 sentences what overfitting is and how you'd detect it
